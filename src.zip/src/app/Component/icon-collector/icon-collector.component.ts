import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icon-collector',
  templateUrl: './icon-collector.component.html',
  styleUrls: ['./icon-collector.component.scss']
})
export class IconCollectorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
