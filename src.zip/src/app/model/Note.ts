export class Note{

  // color: ""
  // createdDate: "2020-08-06T05:54:58.869Z"
  description: string;
  id: string;
  imageUrl: string;
  isArchived: boolean;
  isDeleted: boolean;
  isPined: boolean;
  // label: []
  // linkUrl: ""
  // modifiedDate: "2020-08-06T05:54:58.869Z"
  // noteCheckLists: []
  // noteLabels: []
  // questionAndAnswerNotes: []
  // reminder: []
  title: string;
  // user: {firstName: "Vicky", lastName: "Kumar", role: "user", service: "basic", createdDate: "2020-08-06T04:59:15.075Z", …}

}
