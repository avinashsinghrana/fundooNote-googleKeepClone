export class LoginModel{

  constructor(private userName,
              private password
  ) {
  }
}
